//
//  AliTRVAuthHintListView.h
//  TRiverCore
//
//  Created by AllenHan on 2019/4/20.
//  Copyright © 2019年 TaoBao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AliTRVAuthHintListView : UIView

- (instancetype)initWithFrame:(CGRect)frame agreements:(NSArray<NSDictionary*> *)agreements;

@end


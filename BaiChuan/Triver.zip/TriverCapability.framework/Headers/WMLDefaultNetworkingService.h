//
//  WMLDefaultNetworkingService.h
//  Windmill
//
//  Created by Jason Lee on 2018/5/12.
//

#import <Foundation/Foundation.h>
#import <WindmillTRiverKit/TRVNetworkProtocol.h>

@interface WMLDefaultNetworkingService : NSObject <TRVNetworkProtocol>

@end

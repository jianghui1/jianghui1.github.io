//
//  WMLDefaultLifeCycler.h
//  AliWindmill
//
//  Created by Jason Lee on 2018/6/21.
//

#import <Foundation/Foundation.h>
#import <WindmillTRiverKit/TRVLifeCycleProtocol.h>

@interface AliTRVDefaultLifeCycler : NSObject <TRVLifeCycleProtocol>

@end

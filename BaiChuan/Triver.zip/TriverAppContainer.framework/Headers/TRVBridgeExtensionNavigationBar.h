//
//  TRVBridgeExtensionNavigationBar.h
//  Triver
//
//  Created by zhongweitao on 2019/4/11.
//

#import <Foundation/Foundation.h>
#import <AriverKernel/RVKBridgeExtension.h>

RVK_DEFINE_BRIDGEEXTENSION(TRVBridgeExtensionNavigationBar)

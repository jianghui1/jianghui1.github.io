//
//  TRVAppInfoDelegate.h
//  Triver
//
//  Created by zhongweitao on 2019/4/2.
//

#import <Foundation/Foundation.h>
#import <AriverResource/RVRProtocol.h>

@interface TRVAppInfoCacheDelegate : NSObject <RVRAppPoolManagerProtocol, RVRAppPoolProtocol>

@end

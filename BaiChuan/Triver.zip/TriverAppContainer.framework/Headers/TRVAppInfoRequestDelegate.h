//
//  TRVAppInfoRequestDelegate.h
//  Triver
//
//  Created by zhongweitao on 2019/4/2.
//

#import <Foundation/Foundation.h>
#import <AriverResource/RVRProtocol.h>

@interface TRVAppInfoRequestDelegate : NSObject<RVRRequestManagerDelegate>

@end

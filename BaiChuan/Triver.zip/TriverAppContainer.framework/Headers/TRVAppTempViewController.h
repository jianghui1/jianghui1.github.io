//
//  TRVAppTempViewController.h
//  Triver
//
//  Created by zhongweitao on 2019/4/8.
//

#import <UIKit/UIKit.h>
#import <WindmillTRiverKit/TRVBaseViewController.h>

@interface TRVAppTempViewController : TRVBaseViewController

@end

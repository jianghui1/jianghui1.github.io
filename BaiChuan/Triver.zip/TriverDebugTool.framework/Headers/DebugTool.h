//
//  DebugTool.h
//  DebugTool
//
//  Created by zhongweitao on 2020/7/3.
//  Copyright © 2020 zhongweitao. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DebugTool.
FOUNDATION_EXPORT double DebugToolVersionNumber;

//! Project version string for DebugTool.
FOUNDATION_EXPORT const unsigned char DebugToolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DebugTool/PublicHeader.h>



//
//  VideoEnhance.h
//  VideoEnhance
//
//  Created by 岚遥 on 2020/8/25.
//  Copyright © 2020 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for VideoEnhance.
FOUNDATION_EXPORT double VideoEnhanceVersionNumber;

//! Project version string for VideoEnhance.
FOUNDATION_EXPORT const unsigned char VideoEnhanceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VideoEnhance/PublicHeader.h>



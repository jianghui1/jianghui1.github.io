//
//  LivePlayer.h
//  LivePlayer
//
//  Created by fernando on 2019/8/27.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LivePlayer.
FOUNDATION_EXPORT double LivePlayerVersionNumber;

//! Project version string for LivePlayer.
FOUNDATION_EXPORT const unsigned char LivePlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LivePlayer/PublicHeader.h>



//
//  TRVOptionsPickerView.h
//  API
//
//  Created by 岚遥 on 2019/8/10.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRVOptionPickerProtocol.h"
@class TRVOptionsPickerView;

NS_ASSUME_NONNULL_BEGIN

@interface TRVOptionsPickerView : UIView <TRVOptionPickerProtocol>

@end

NS_ASSUME_NONNULL_END

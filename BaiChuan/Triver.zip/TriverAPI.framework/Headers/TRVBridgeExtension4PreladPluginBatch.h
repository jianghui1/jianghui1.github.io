//
//  TRVBridgeExtension4PreladPluginBatch.h
//  API
//
//  Created by 岚遥 on 2020/3/10.
//  Copyright © 2020 Taobao. All rights reserved.
//

#import <AriverKernel/RVKBridgeExtension.h>

NS_ASSUME_NONNULL_BEGIN

RVK_DEFINE_BRIDGEEXTENSION(TRVBridgeExtension4PreladPluginBatch)

NS_ASSUME_NONNULL_END

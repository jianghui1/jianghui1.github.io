//
//  TRVAppContainer+Runtime.h
//  Runtime
//
//  Created by xuyouyang on 2020/1/2.
//  Copyright © 2020 Taobao. All rights reserved.
//

#import <TriverAppContainer/TRVAppContainer.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRVAppContainer (Runtime)

@property (nonatomic, strong) NSString *snapshotTemplateType;

@end

NS_ASSUME_NONNULL_END

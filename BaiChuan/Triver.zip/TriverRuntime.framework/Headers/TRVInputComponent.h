//
//  TRVInputComponent.h
//  Runtime
//
//  Created by 岚遥 on 2019/8/23.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <AriverRuntime/RVTComponent.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRVInputComponent : RVTComponent

@end

NS_ASSUME_NONNULL_END

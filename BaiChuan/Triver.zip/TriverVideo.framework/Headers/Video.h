//
//  Video.h
//  Video
//
//  Created by 岚遥 on 2019/7/26.
//  Copyright © 2019 taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Video.
FOUNDATION_EXPORT double VideoVersionNumber;

//! Project version string for Video.
FOUNDATION_EXPORT const unsigned char VideoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Video/PublicHeader.h>



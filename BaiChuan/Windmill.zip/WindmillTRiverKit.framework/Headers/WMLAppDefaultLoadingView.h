//
//  WMLAppDefaultLoadingView.h
//  AppContainer
//
//  Created by AllenHan on 2018/5/16.
//  Copyright © 2018年 AllenHan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRVUIProviderProtocol.h"

@interface WMLAppDefaultLoadingView : UIView <TRVLoadingViewProtocol>

@end

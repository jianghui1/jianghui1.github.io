//
//  TRiverKit.h
//  TRiverKit
//
//  Created by AllenHan on 2019/4/2.
//  Copyright © 2019年 TaoBao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TRiverKit.
FOUNDATION_EXPORT double TRiverKitVersionNumber;

//! Project version string for TRiverKit.
FOUNDATION_EXPORT const unsigned char TRiverKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TRiverKit/PublicHeader.h>



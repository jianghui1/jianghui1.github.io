//
//  TRVThreadSafeMutableDictionary.h
//  AppContainer
//
//  Created by Jason Lee on 2018/6/26.
//  Copyright © 2018年 AllenHan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRVThreadSafeMutableDictionary <KeyType, ObjectType> : NSMutableDictionary

@end

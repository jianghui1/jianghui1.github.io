//
//  Config.h
//  DWInteractiveSDK
//
//  Created by Yongchao Lao on 2020/9/30.
//  Copyright © 2020 alibaba. All rights reserved.
//

#ifndef Config_h
#define Config_h

#define BUILD_FOR_BAICHUAN 1

#endif /* Config_h */

//
//  NSError+AlibcStr.h
//  AlibcTradeCommonSDK
//
//  Created by zhongweitao on 2020/6/30.
//

#import <Foundation/Foundation.h>

@interface NSError (AlibcStr)

- (NSString *)allDesStr;

@end

//
//  AlibcTradeMtopModels.h
//  AlibcTradeUltimateBizSDK
//
//  Created by Jason Lee on 2020/3/12.
//  Copyright © 2020 shan yi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AlibcTradeCommonSDK/AlibcMtopCmd.h>

@interface AlibcTradeGetAppSuiteConfigCmd : AlibcMtopCmd

@end

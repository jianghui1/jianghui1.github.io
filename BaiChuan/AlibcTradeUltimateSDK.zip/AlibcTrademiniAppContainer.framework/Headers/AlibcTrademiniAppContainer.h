//
//  AlibcTrademiniAppContainer.h
//  AlibcTrademiniAppContainer
//
//  Created by shan yi on 2019/10/31.
//  Copyright © 2019 shan yi. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AlibcTrademiniAppContainer.
FOUNDATION_EXPORT double AlibcTrademiniAppContainerVersionNumber;

//! Project version string for AlibcTrademiniAppContainer.
FOUNDATION_EXPORT const unsigned char AlibcTrademiniAppContainerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AlibcTrademiniAppContainer/PublicHeader.h>



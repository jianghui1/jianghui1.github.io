//
//  RVKSchedulableProtocol.h
//  NebulaKernel
//
//  Created by theone on 2018/8/24.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RVKSchedulableProtocol <NSObject>

@end

//
//  AriverSecurity.h
//  AriverSecurity
//
//  Created by theone on 2019/4/9.
//  Copyright © 2019 Alipay. All rights reserved.
//

#ifndef AriverSecurity_h
#define AriverSecurity_h

#import <AriverSecurity/RVSConfigService.h>

#endif /* AriverSecurity_h */

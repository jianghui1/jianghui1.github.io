//
//  RVAPerformanceMonitor.h
//  AriverApp
//
//  Created by yemingyu on 2018/9/29.
//  Copyright © 2018 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RVAPerformanceMonitor : NSObject

+ (void)nbthirdParty_startUpPerformanceLog:(NSString*)type;

@end

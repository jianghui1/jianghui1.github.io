//
//  RVASessionLifecycleProxy.h
//  RVAService
//
//  Created by chenwenhong on 15/8/26.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AriverApp/RVASessionDelegateProtocol.h>

@interface RVASessionDelegate : NSObject <RVASessionDelegateProtocol>

@end

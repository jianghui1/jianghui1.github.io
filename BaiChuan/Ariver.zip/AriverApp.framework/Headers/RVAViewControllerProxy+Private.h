//
//  RVAViewControllerProxy+Private.h
//  AriverApp
//
//  Created by chenwenhong on 16/1/19.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <AriverApp/AriverApp.h>

@interface RVAViewControllerProxy (Private)

- (void)sendCreateRightItemsEvent;

@end

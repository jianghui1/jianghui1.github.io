//
//  RVAToolbarMenuEvent+RVAPrivate.h
//  AriverApp
//
//  Created by chenwenhong on 15/9/10.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import "RVAToolbarMenuEvent.h"

@interface RVAToolbarMenuEvent (RVAPrivate)

+ (instancetype)showEvent;

+ (instancetype)hideEvent;

@end

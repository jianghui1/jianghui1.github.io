//
//  RVAViewController.h
//  RVAService
//
//  Created by chenwenhong on 15/8/21.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RVAViewController : UIViewController <RVKViewControllerProtocol>

@end

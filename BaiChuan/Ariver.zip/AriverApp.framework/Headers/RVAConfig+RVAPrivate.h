//
//  RVAConfiguration+RVAPrivate.h
//  AriverApp
//
//  Created by chenwenhong on 15/10/10.
//  Copyright © 2015年 Alipay. All rights reserved.
//

#import <AriverApp/AriverApp.h>

@interface RVAConfig (RVAPrivate)

- (void)requestUpdateConfiguration;

@end

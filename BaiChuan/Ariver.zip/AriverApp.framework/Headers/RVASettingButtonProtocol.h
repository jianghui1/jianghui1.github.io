//
//  RVASettingButtonProtocol.h
//  AriverApp
//
//  Created by chenwenhong on 15/9/30.
//  Copyright © 2015年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RVASettingButtonProtocol <NSObject>

- (void)setRedDot:(int)redDot;

@end

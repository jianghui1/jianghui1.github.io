//
//  NSString+NXR.h
//  NebulaResource
//
//  Created by 扶瑶 on 16/3/1.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (RVR)

- (id)NXRJson;

@end

//
//  RVPJSApiResPreviewImage.h
//  AriverApi
//
//  Created by quankai on 2019/5/6.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AriverKernel/RVKJSApiResponseBase.h>

@interface RVPJSApiResPreviewImage : RVKJSApiResponseBase

@property (nonatomic, copy) NSNumber *success;

@end

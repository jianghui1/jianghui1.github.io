//
//  RVPJSApiReqSaveVideoToPhotosAlbum.h
//  AriverApi
//
//  Created by quankai on 2019/5/6.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AriverKernel/RVKJSApiRequestBase.h>

@interface RVPJSApiReqSaveVideoToPhotosAlbum : RVKJSApiRequestBase

@property (nonatomic, copy) NSString *src;

@end

//
//  RVPJSApiResVerifyIdentity.h
//  AriverApi
//
//  Created by xuyouyang on 2019/5/9.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AriverKernel/RVKJSApiResponseBase.h>

NS_ASSUME_NONNULL_BEGIN

// 返回值直接取 [[VIEngine engine] startWithVerifyId:] 里面的返回值

@interface RVPJSApiResVerifyIdentity : RVKJSApiResponseBase

@end

NS_ASSUME_NONNULL_END

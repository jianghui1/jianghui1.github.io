//
//  RVF4RemoveSavedFile.h
//  AriverFileManager
//
//  Created by pingyang.yq on 2019/4/29.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AriverKernel/AriverKernel.h>
#import <AriverKernel/RVKBridgeExtension.h>

NS_ASSUME_NONNULL_BEGIN

RVK_DEFINE_BRIDGEEXTENSION(RVPBridgeExtension4RemoveSavedFile)

NS_ASSUME_NONNULL_END

//
//  UT_Common.h
//  UT_Common
//
//  Created by ljianfeng on 2019/6/4.
//  Copyright © 2019 Taobao.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UT_Common.
FOUNDATION_EXPORT double UT_CommonVersionNumber;

//! Project version string for UT_Common.
FOUNDATION_EXPORT const unsigned char UT_CommonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UT_Common/PublicHeader.h>



/*
 * WVRuleWebViewController.h
 * 
 * Created by WindVane.
 * Copyright (c) 2017年 阿里巴巴-淘宝技术部. All rights reserved.
 */

#import "WVViewController.h"

/**
 这个类已将主要功能迁移到 WVViewController。
 */
@interface WVRuleWebViewController : WVViewController
@end

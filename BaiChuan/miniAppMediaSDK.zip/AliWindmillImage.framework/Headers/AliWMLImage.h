//
//  AliWMLImage.h
//  Image
//
//  Created by ali_liuhui on 2018/12/10.
//  Copyright © 2018 alibaba.inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AliWMLImage : NSObject

+ (void)setup;

@end


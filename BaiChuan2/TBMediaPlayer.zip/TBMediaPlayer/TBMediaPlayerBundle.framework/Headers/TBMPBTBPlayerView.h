//
//  TBMPBTBPlayerView.h
//  TBMediaPlayerBundle
//
//  Created by qiufu on 17/01/2018.
//  Copyright © 2018 CX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TBMediaPlayerBundle/TBMPBPlayerProtocol.h>

@interface TBMPBTBPlayerView : UIView<TBMPBPlayerProtocol>

@end

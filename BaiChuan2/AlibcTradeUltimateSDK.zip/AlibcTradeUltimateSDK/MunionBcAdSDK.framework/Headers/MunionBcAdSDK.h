//
//  MunionBcAdSDK.h
//  MunionBcAdSDK
//
//  Created by 江滔 on 2019/11/27.
//  Copyright © 2019 江滔. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MunionBcAdSDK.
FOUNDATION_EXPORT double MunionBcAdSDKVersionNumber;

//! Project version string for MunionBcAdSDK.
FOUNDATION_EXPORT const unsigned char MunionBcAdSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MunionBcAdSDK/PublicHeader.h>

#import <MunionBcAdSDK/munion.h>
#import <MunionBcAdSDK/TKCpsManage.h>

//
//  RVASession+RVAPrivate.h
//  RVAService
//
//  Created by chenwenhong on 15/8/26.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import "RVASession.h"

@interface RVASession (RVAPrivate)

- (instancetype)initWithContext:(RVASessionContext *)context;

@end

//
//  RVAToolbarMenu.h
//  AriverApp
//
//  Created by chenwenhong on 15/9/9.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//
#if INDEPENDENT

#import <Foundation/Foundation.h>
#import "RVAToolbarMenuProtocol.h"

@interface RVAToolbarMenu : NSObject <RVAToolbarMenuProtocol>

@end

#endif

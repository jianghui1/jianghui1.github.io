//
//  RVKScene+RVA.h
//  AriverApp
//
//  Created by chenwenhong on 15/9/21.
//  Copyright © 2015年 Alipay. All rights reserved.
//

@interface RVKScene (RVA)

@property(nonatomic, copy) NSString *channelId;

@end

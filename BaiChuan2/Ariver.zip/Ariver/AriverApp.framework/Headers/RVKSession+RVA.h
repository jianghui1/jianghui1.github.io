//
//  RVKSession+RVAService.h
//  RVAService
//
//  Created by chenwenhong on 15/8/26.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//
#import "RVASession.h"
@interface RVKSession (RVA)

- (RVASession *)session;

@end

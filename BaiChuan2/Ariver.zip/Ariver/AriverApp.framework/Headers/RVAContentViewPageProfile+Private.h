//
//  RVAContentViewPageProfile+Private.h
//  AriverApp
//
//  Created by chenwenhong on 15/12/29.
//  Copyright © 2015年 Alipay. All rights reserved.
//

#import <AriverApp/AriverApp.h>

@interface RVAContentViewPageProfile (Private)

- (void)reportJSMonitor:(NSArray *)monitorData;

- (void)reportCreateDate:(NSDate *)date;

@end

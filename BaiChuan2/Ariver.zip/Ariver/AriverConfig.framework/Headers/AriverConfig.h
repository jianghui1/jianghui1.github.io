//
//  AriverConfig.h
//  AriverConfig
//
//  Created by theone on 2019/4/24.
//  Copyright © 2019 Alipay. All rights reserved.
//

#ifndef AriverConfig_h
#define AriverConfig_h

#import <AriverConfig/RVCConfigService.h>

#endif /* AriverConfig_h */

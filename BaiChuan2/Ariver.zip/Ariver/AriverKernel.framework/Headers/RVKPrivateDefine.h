//
//  RVKPrivateDefine.h
//  NebulaPoseidon
//
//  Created by chenwenhong on 15/9/30.
//  Copyright © 2015年 Alipay. All rights reserved.
//

#ifndef RVKPrivateDefine_h
#define RVKPrivateDefine_h

#define kRVKSDKVersion                              @"1.2.0.0"

#define kSharedPluginGroupId                        @"^NEBULAPOSEIDON^_kSharedPluginGroupId_^NEBULAPOSEIDON^"
#define kSharedJsApiGroupId                         @"^NEBULAPOSEIDON^_kSharedJsApiGroupId_^NEBULAPOSEIDON^"


#endif /* RVKPrivateDefine_h */

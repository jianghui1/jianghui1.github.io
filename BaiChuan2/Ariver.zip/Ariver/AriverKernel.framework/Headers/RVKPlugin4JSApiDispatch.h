//
//  NXKPlugin4JSApiDispatch.h
//  NebulaKernel
//
//  Created by theone on 2018/9/12.
//  Copyright © 2018年 Alipay. All rights reserved.
//


@interface RVKPlugin4JSApiDispatch : NSObject <RVKPluginProtocol>

@end

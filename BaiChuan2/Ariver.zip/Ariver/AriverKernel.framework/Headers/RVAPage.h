//
//  RVAPage.h
//  AriverKernel
//
//  Created by theone on 2019/4/2.
//  Copyright © 2019 Alipay. All rights reserved.
//

#import <AriverKernel/AriverKernel.h>

NS_ASSUME_NONNULL_BEGIN

@interface RVAPage : RVKScene

@end

NS_ASSUME_NONNULL_END

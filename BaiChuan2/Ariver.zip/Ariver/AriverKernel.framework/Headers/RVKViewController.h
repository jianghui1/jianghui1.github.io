//
//  RVKViewController.h
//  Poseidon
//
//  Created by chenwenhong on 14-8-8.
//  Copyright (c) 2014年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RVKViewControllerProtocol.h"

//VC基类
@interface RVKViewController : UIViewController <RVKViewControllerProtocol>

@end


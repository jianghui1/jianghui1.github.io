//
//  AliWindmillImage.h
// 
//  Created by Windmill.
//  Copyright 2018 Taobao Inc. All rights reserved.
//

#ifdef __OBJC__

#import "AliWMLImage.h"
#import "AliWindmillImage.h"
#import "TBPHPhotoObject.h"
#import "TBPHPublisher.h"
#import "WMLAppChooseImageProtocol.h"
#import "WMLAppCompressImageProtocol.h"
#import "WMLAppGetImageInfoProtocol.h"
#import "WMLAppImage.h"
#import "WMLAppPreviewImageProtocol.h"

#endif /* __OBJC__ */

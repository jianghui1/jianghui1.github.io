//
//  TRVUserTrackProtocol.h
//  TRiverKit
//
//  Created by AllenHan on 2019/9/11.
//  Copyright © 2019年 TaoBao. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TRVUserTrackProtocol <NSObject>
@optional
- (void)skipPage:(id)pageObject;
@end

/*
 * WindVane.h
 * 
 * Created by WindVane.
 * Copyright (c) 2014年 阿里巴巴-无线事业部. All rights reserved.
 */

#ifdef __OBJC__

#if __has_include(<WindVaneCore/WindVaneCore.h>)
#import <WindVaneCore/WindVaneCore.h>
#endif

#if __has_include(<WindVaneBasic/WindVaneBasic.h>)
#import <WindVaneBasic/WindVaneBasic.h>
#endif

#endif /* __OBJC__ */

//
//  ALPLinkPartnerSDK.h
//  ALPLinkPartnerSDK
//
//  Created by czp on 16/9/22.
//  Copyright © 2016年 czp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ALSmartLink.h"
//#import "ALPTBLinkPartnerSDK.h"

//! Project version number for ALPLinkPartnerSDK.
FOUNDATION_EXPORT double ALPLinkPartnerSDKVersionNumber;

//! Project version string for ALPLinkPartnerSDK.
FOUNDATION_EXPORT const unsigned char ALPLinkPartnerSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ALPLinkPartnerSDK/PublicHeader.h>



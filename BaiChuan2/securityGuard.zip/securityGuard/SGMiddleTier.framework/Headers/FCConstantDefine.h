//
//  FCConstantDefine.m
//  SecurityGuardMiddleTier
//
//  Created by yhN on 2019/4/4.
//  Copyright © 2019年 Li Fengzhong. All rights reserved.
//

#import <Foundation/Foundation.h>

#define KEY_NATIVE_LOGIN_MODULE     @"key_login_module"
#define KEY_RESEND_DATA             @"key_resend_data"
#define KEY_WUA_DATA                @"key_wua_data"
#define KEY_CUSTOM_UI_UTIL          @"key_custom_ui_util"

//
//  SGNoCaptcha.h
//  SecurityGuardMain
//
//  Created by lifengzhong on 2016/12/29.
//  Copyright © 2016年 Li Fengzhong. All rights reserved.
//

#ifndef SGNoCaptcha_h
#define SGNoCaptcha_h

#import <Foundation/Foundation.h>

 

#ifdef _SG_INTERNAL_VERSION_

#import "ISecurityGuardNoCaptcha.h"

#endif

#import "ISecurityGuardOpenNoCaptcha.h"

#endif /* SGNoCaptcha_h */

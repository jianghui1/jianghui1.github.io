//
//  SGIndieKit.h
//  SecurityGuardMain
//
//  Created by lifengzhong on 2016/12/29.
//  Copyright © 2016年 Li Fengzhong. All rights reserved.
//

#ifndef SGIndieKit_h
#define SGIndieKit_h

#import <Foundation/Foundation.h>

#import "ISecurityGuardIndieKit.h"
//#import "ISecurityGuardOpenMark.h"

#endif /* SGIndieKit_h */

//
//  LocalDebug.h
//  LocalDebug
//
//  Created by zhongweitao on 2019/8/29.
//  Copyright © 2019 zhongweitao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LocalDebug.
FOUNDATION_EXPORT double LocalDebugVersionNumber;

//! Project version string for LocalDebug.
FOUNDATION_EXPORT const unsigned char LocalDebugVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LocalDebug/PublicHeader.h>



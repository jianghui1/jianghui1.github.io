//
//  WMLActionSheetButton.h
//  JDYUIControls
//
//  Created by 连墨 on 2018/4/11.
//  Copyright © 2018年 连墨. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AliTRVActionSheetButton : UIButton
@property (nonatomic, assign) NSUInteger rowIndexInSection;
@end

@interface AliTRVActionSheetButtonIconTitle : AliTRVActionSheetButton
@end

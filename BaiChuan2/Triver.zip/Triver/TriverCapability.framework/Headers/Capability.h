//
//  Capability.h
//  Capability
//
//  Created by zhongweitao on 2019/5/27.
//  Copyright © 2019 zhongweitao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Capability.
FOUNDATION_EXPORT double CapabilityVersionNumber;

//! Project version string for Capability.
FOUNDATION_EXPORT const unsigned char CapabilityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Capability/PublicHeader.h>



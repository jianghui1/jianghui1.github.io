//
//  WMLDefaultNavBar.h
//  AliWindmill
//
//  Created by Jason Lee on 2018/11/12.
//  Copyright © 2018年 alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WMLAppPageNavBarConsts.h"
#import "AliTRVBaseNaviBar.h"
#import <UIKit/UIKit.h>

@interface AliTRVDefaultNavBar : AliTRVBaseNaviBar

@end

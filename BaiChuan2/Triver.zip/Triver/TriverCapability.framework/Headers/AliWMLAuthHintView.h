//
//  AliWMLAuthHintView.h
//  AliWindmill
//
//  Created by AllenHan on 2018/2/2.
//

#import <UIKit/UIKit.h>

@interface AliWMLAuthHintView : UIView

- (instancetype)initWithHintUrl:(NSString *)hintUrl frame:(CGRect)frame;

@end

//
//  AppContainer.h
//  AppContainer
//
//  Created by CaiXiaomin on 2019/3/29.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AppContainer.
FOUNDATION_EXPORT double AppContainerVersionNumber;

//! Project version string for AppContainer.
FOUNDATION_EXPORT const unsigned char AppContainerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppContainer/PublicHeader.h>



//
//  TRVBridgeExtension4MemoryWarning.h
//  API
//
//  Created by 岚遥 on 2019/12/26.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <AriverKernel/RVKBridgeExtension.h>

NS_ASSUME_NONNULL_BEGIN

RVK_DEFINE_BRIDGEEXTENSION(TRVBridgeExtension4MemoryWarning)

NS_ASSUME_NONNULL_END

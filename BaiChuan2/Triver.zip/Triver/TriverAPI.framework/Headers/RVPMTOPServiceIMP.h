//
//  RVPMTOPServiceIMP.h
//  API
//
//  Created by AllenHan on 2019/4/22.
//  Copyright © 2019年 Taobao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AriverKernel/RVKExtension.h>
#import <AriverAuth/TRVSMtopServiceProtocol.h>

@interface RVPMTOPServiceIMP : RVKExtension <RVSMTOPServiceProtocol>

@end


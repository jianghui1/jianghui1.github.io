//
//  TRVAPI.h
//  API
//
//  Created by xuyouyang on 2019/4/16.
//  Copyright © 2019 Taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TRVAPI : NSObject

+ (void)setup;

@end

NS_ASSUME_NONNULL_END
